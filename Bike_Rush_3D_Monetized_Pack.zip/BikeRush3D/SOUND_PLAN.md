# Sound & Music Plan

Recommended original/licensed audio:
- Menu music: upbeat 90–110 BPM loop
- Race music: energetic 120–140 BPM loop
- Coin pickup: short bright chime
- Collision: short impact sound
- Level up: rising confirmation sound
- Button tap: soft click
- Game over: short descending sting

Use only audio you own or have a commercial license to use. Keep mobile file sizes small.
