# Bike Rush 3D — Brand Pack

## App name
Bike Rush 3D

## Short tagline
Race. Ride. Rush.

## Visual direction
Fast, colorful, arcade-style bicycle racing. The prototype uses procedural 3D shapes;
replace these with licensed/custom 3D assets before commercial release.

## Suggested icon
A bright red bicycle silhouette on a dark road, with a yellow speed streak.
Export at 512x512 PNG for the Play Store listing and provide adaptive-icon layers
for Android if desired.

## Store screenshots
Prepare at least 4 portrait screenshots:
1. Main race with obstacle and coins
2. Bike garage
3. Level progression
4. Game-over / best score

Do not use misleading UI, fake rewards, or claims the game does not provide.
