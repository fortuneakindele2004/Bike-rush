extends Node3D

enum State { MENU, PLAYING, GARAGE, GAME_OVER }
var state = State.MENU

var bike_x := 0.0
var speed := 9.0
var distance := 0.0
var score := 0
var coins := 0
var total_coins := 0
var level := 1
var best_score := 0
var selected_bike := 0
var game_over := false
var road_width := 8.0
var obstacles: Array[Dictionary] = []
var coin_objects: Array[Dictionary] = []
var spawn_timer := 0.0
var coin_timer := 0.0
var rng := RandomNumberGenerator.new()

var bike: MeshInstance3D
var camera: Camera3D
var score_label: Label
var coin_label: Label
var level_label: Label
var title: Label
var message: Label
var play_button: Button
var garage_button: Button
var back_button: Button
var restart_button: Button
var left_button: Button
var right_button: Button
var bike_button: Button

var bike_colors = [
    Color(0.95,0.12,0.08),
    Color(0.08,0.35,0.95),
    Color(0.08,0.8,0.3),
    Color(0.65,0.12,0.85)
]
var bike_names = ["Racer", "Blue Bolt", "Green Flash", "Purple Storm"]
var bike_costs = [0, 100, 250, 500]

func _ready():
    rng.randomize()
    build_world()
    build_bike()
    build_ui()
    show_menu()

func mat(color: Color) -> StandardMaterial3D:
    var m = StandardMaterial3D.new()
    m.albedo_color = color
    m.metallic = 0.1
    m.roughness = 0.65
    return m

func box(size: Vector3, color: Color) -> MeshInstance3D:
    var n = MeshInstance3D.new()
    var mesh = BoxMesh.new()
    mesh.size = size
    n.mesh = mesh
    n.material_override = mat(color)
    add_child(n)
    return n

func build_world():
    var ground = box(Vector3(30, 0.2, 240), Color(0.12,0.55,0.16))
    ground.position = Vector3(0,-0.2,0)

    var road = box(Vector3(road_width,0.12,240), Color(0.07,0.07,0.08))
    road.position = Vector3(0,-0.05,0)

    for x in [-2.0,2.0]:
        var line = box(Vector3(0.12,0.03,240), Color(0.95,0.95,0.95))
        line.position = Vector3(x,0.02,0)

    camera = Camera3D.new()
    add_child(camera)
    camera.position = Vector3(0,5.5,10)
    camera.rotation_degrees = Vector3(-18,0,0)
    camera.current = true

func build_bike():
    bike = box(Vector3(0.8,0.7,1.8), bike_colors[selected_bike])
    bike.position = Vector3(0,0.65,5)

    var seat = box(Vector3(0.45,0.15,0.45), Color(0.02,0.02,0.02))
    seat.position = Vector3(0,1.15,5.15)

    var handle = box(Vector3(1.0,0.12,0.12), Color(0.85,0.85,0.85))
    handle.position = Vector3(0,1.15,4.35)

func recolor_bike():
    bike.material_override = mat(bike_colors[selected_bike])

func label(text_value: String, size: int) -> Label:
    var l = Label.new()
    l.text = text_value
    l.add_theme_font_size_override("font_size", size)
    return l

func build_ui():
    var layer = CanvasLayer.new()
    add_child(layer)

    title = label("BIKE RUSH 3D", 52)
    title.position = Vector2(125,90)
    layer.add_child(title)

    score_label = label("", 28)
    score_label.position = Vector2(25,25)
    layer.add_child(score_label)

    coin_label = label("", 25)
    coin_label.position = Vector2(25,65)
    layer.add_child(coin_label)

    level_label = label("", 25)
    level_label.position = Vector2(520,25)
    layer.add_child(level_label)

    play_button = Button.new()
    play_button.text = "PLAY"
    play_button.position = Vector2(220,420)
    play_button.size = Vector2(280,90)
    play_button.add_theme_font_size_override("font_size", 34)
    play_button.pressed.connect(start_game)
    layer.add_child(play_button)

    garage_button = Button.new()
    garage_button.text = "BIKE GARAGE"
    garage_button.position = Vector2(220,535)
    garage_button.size = Vector2(280,80)
    garage_button.add_theme_font_size_override("font_size", 28)
    garage_button.pressed.connect(show_garage)
    layer.add_child(garage_button)

    bike_button = Button.new()
    bike_button.text = ""
    bike_button.position = Vector2(190,400)
    bike_button.size = Vector2(340,80)
    bike_button.add_theme_font_size_override("font_size", 25)
    bike_button.pressed.connect(select_next_bike)
    layer.add_child(bike_button)

    back_button = Button.new()
    back_button.text = "BACK"
    back_button.position = Vector2(25,25)
    back_button.size = Vector2(150,70)
    back_button.pressed.connect(show_menu)
    layer.add_child(back_button)

    left_button = Button.new()
    left_button.text = "◀"
    left_button.position = Vector2(30,1050)
    left_button.size = Vector2(190,130)
    left_button.add_theme_font_size_override("font_size", 50)
    left_button.pressed.connect(func(): bike_x -= 0.9)
    layer.add_child(left_button)

    right_button = Button.new()
    right_button.text = "▶"
    right_button.position = Vector2(500,1050)
    right_button.size = Vector2(190,130)
    right_button.add_theme_font_size_override("font_size", 50)
    right_button.pressed.connect(func(): bike_x += 0.9)
    layer.add_child(right_button)

    message = label("", 40)
    message.position = Vector2(150,500)
    layer.add_child(message)

    restart_button = Button.new()
    restart_button.text = "RESTART"
    restart_button.position = Vector2(245,650)
    restart_button.size = Vector2(230,90)
    restart_button.add_theme_font_size_override("font_size", 30)
    restart_button.pressed.connect(start_game)
    layer.add_child(restart_button)

func hide_all():
    play_button.visible = false
    garage_button.visible = false
    bike_button.visible = false
    back_button.visible = false
    left_button.visible = false
    right_button.visible = false
    restart_button.visible = false
    score_label.visible = false
    coin_label.visible = false
    level_label.visible = false
    message.visible = false

func show_menu():
    state = State.MENU
    hide_all()
    title.visible = true
    play_button.visible = true
    garage_button.visible = true
    title.text = "BIKE RUSH 3D"
    message.text = "Best Score: %d" % best_score
    message.visible = true

func show_garage():
    state = State.GARAGE
    hide_all()
    title.visible = true
    back_button.visible = true
    bike_button.visible = true
    message.visible = true
    update_garage_text()

func update_garage_text():
    bike_button.text = "%s  —  %d coins" % [bike_names[selected_bike], bike_costs[selected_bike]]
    message.text = "YOUR COINS: %d\nTap the bike button to change bikes." % total_coins

func select_next_bike():
    selected_bike = (selected_bike + 1) % bike_names.size()
    recolor_bike()
    update_garage_text()

func start_game():
    state = State.PLAYING
    hide_all()
    score_label.visible = true
    coin_label.visible = true
    level_label.visible = true
    left_button.visible = true
    right_button.visible = true
    title.visible = false
    reset_round()

func reset_round():
    for item in obstacles:
        item.node.queue_free()
    for item in coin_objects:
        item.node.queue_free()
    obstacles.clear()
    coin_objects.clear()
    bike_x = 0
    speed = 9.0
    distance = 0
    score = 0
    coins = 0
    level = 1
    game_over = false
    bike.position.x = 0

func spawn_obstacle():
    var x = rng.randf_range(-3.0,3.0)
    var o = box(Vector3(1.4,1.2,1.2), Color(0.95,0.48,0.04))
    o.position = Vector3(x,0.6,-80)
    obstacles.append({"node":o,"z":-80.0})

func spawn_coin():
    var x = rng.randf_range(-3.0,3.0)
    var c = box(Vector3(0.45,0.45,0.15), Color(1.0,0.8,0.05))
    c.position = Vector3(x,1.0,-80)
    coin_objects.append({"node":c,"z":-80.0})

func _process(delta):
    if state != State.PLAYING or game_over:
        return

    bike_x = clamp(bike_x, -3.2, 3.2)
    bike.position.x = lerp(bike.position.x, bike_x, delta*8.0)

    speed += delta * 0.10
    distance += speed * delta
    level = 1 + int(distance / 350.0)
    score = int(distance * 10) + coins * 50

    spawn_timer -= delta
    coin_timer -= delta

    if spawn_timer <= 0:
        spawn_obstacle()
        spawn_timer = max(0.55, 1.5 - speed*0.035)

    if coin_timer <= 0:
        spawn_coin()
        coin_timer = 0.85

    for i in range(obstacles.size()-1,-1,-1):
        var item = obstacles[i]
        item.z += speed * delta
        item.node.position.z = item.z
        if item.z > 12:
            item.node.queue_free()
            obstacles.remove_at(i)
        elif abs(item.z-5) < 1.3 and abs(item.node.position.x-bike.position.x) < 1.0:
            end_game()

    for i in range(coin_objects.size()-1,-1,-1):
        var item = coin_objects[i]
        item.z += speed * delta
        item.node.position.z = item.z
        item.node.rotate_y(delta*5)
        if item.z > 12:
            item.node.queue_free()
            coin_objects.remove_at(i)
        elif abs(item.z-5) < 1.3 and abs(item.node.position.x-bike.position.x) < 0.9:
            coins += 1
            total_coins += 1
            item.node.queue_free()
            coin_objects.remove_at(i)

    score_label.text = "SCORE: %d" % score
    coin_label.text = "COINS: %d" % coins
    level_label.text = "LEVEL %d" % level

func _input(event):
    if state != State.PLAYING:
        return
    if event is InputEventScreenTouch and event.pressed:
        if event.position.x < get_viewport().size.x/2:
            bike_x -= 0.9
        else:
            bike_x += 0.9

func end_game():
    game_over = true
    best_score = max(best_score, score)
    hide_all()
    title.visible = true
    message.text = "GAME OVER\nScore: %d\nBest: %d\nCoins: %d" % [score,best_score,coins]
    message.visible = true
    restart_button.visible = true
    back_button.visible = true

func _notification(what):
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:
        show_menu()
