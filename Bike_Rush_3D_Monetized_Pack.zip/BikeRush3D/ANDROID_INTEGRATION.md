# Android Monetization Integration

The final Android build should integrate:
- Google Play Billing for in-app purchases.
- A supported mobile ads SDK such as Google Mobile Ads/AdMob.

Do not hard-code private keys, service-account credentials, or payment credentials.

For release:
1. Create products in Play Console using the product IDs in economy.json (or your final IDs).
2. Configure the ads provider and create Android ad unit IDs.
3. Use test ad unit IDs while developing.
4. Add the final IDs only in the release configuration.
5. Test purchases with Play Console's testing tracks/accounts.
6. Export and sign the final AAB.
