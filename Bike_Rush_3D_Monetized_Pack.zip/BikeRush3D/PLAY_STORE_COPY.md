# Google Play Store Draft

## Title
Bike Rush 3D

## Short description
Race your bicycle, dodge obstacles, collect coins and chase your highest score!

## Full description
Get ready for a fast arcade bicycle ride!

Bike Rush 3D puts you on an endless road where every second counts. Move left and
right, avoid obstacles, collect coins and keep riding as the speed increases.

FEATURES
• Simple touch controls
• Endless racing gameplay
• Coins and score system
• Increasing difficulty
• Multiple bikes to unlock
• Bike garage
• Level progression
• Best-score challenge

How far can you ride?

This description should be reviewed and updated to match the final shipped feature set.
