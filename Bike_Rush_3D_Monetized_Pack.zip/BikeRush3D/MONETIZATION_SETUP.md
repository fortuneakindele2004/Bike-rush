# Bike Rush 3D — Monetization Setup

## Model
Free-to-play with:
1. Rewarded ads: watch an ad to receive a small coin bonus after a race.
2. Optional one-time purchases:
   - Starter Coin Pack
   - Racer Pack
   - Remove Ads
3. No forced purchase is required to play.

## Suggested products
- coins_100: 100 coins
- coins_500: 500 coins
- remove_ads: permanently remove ads
- racer_pack: cosmetic bike/coin bundle

Product IDs are examples and must be created with the exact IDs you choose in Google Play
Console before the game can sell them.

## Ad setup
Use Google AdMob or another supported mobile advertising provider. Create the ad account
under your own details. Never put secret account credentials in the game source.

Recommended placements:
- Rewarded ad: after a race, optional.
- Interstitial: only at natural breaks and not excessively.
- Banner: optional; avoid blocking gameplay.

During development, use TEST ads. Do not click your own live ads.

## Payments
Google Play Billing should handle Android in-app purchases. The developer/merchant
account must belong to you. Configure products in Play Console, then connect the final
product IDs in the game.

## Revenue
Revenue depends on player count, engagement, ad demand, purchase conversion, taxes,
platform fees, and the countries where players are located. There is no guaranteed
amount.

## Current prototype
The included game already has coins and a garage. This document defines the next
integration layer; real ad serving and Google Play Billing require the final Android
export plus the relevant SDK/plugin configuration and your developer/merchant accounts.
