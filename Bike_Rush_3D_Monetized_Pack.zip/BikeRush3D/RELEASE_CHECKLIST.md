# Android / Google Play Release Checklist

1. Install Godot 4.x and open the project.
2. Set a unique Android application ID/package name, for example:
   com.yourstudio.bikerush3d
3. Add the final app icon and splash screen.
4. Replace prototype geometry with final licensed/custom 3D art.
5. Add final music and sound effects with proper licenses.
6. Test touch controls on several Android screen sizes.
7. Test pause/resume, back button, orientation, low memory, and offline behavior.
8. Remove debug/test text.
9. Configure a release signing key and keep it secure.
10. Export an Android App Bundle (.aab) for Google Play.
11. Create the Play Console store listing.
12. Add screenshots, app icon, description, category and contact details.
13. Complete Google's current content, data-safety and target-API declarations
    that apply to the final app.
14. Complete testing/review requirements shown in Play Console for the developer account.
15. Upload the signed AAB and submit for review.

Google Play requirements can change, so verify the current requirements in Play Console
before submission.
