# Bike Rush 3D — upgraded starter

This is an expanded Godot 4 starter for a mobile bicycle endless-runner.

Included:
- Main menu
- Play mode
- Bike garage / bike selection
- Four bike color variants
- Coins and score
- Increasing speed
- Levels
- Obstacles
- Touch controls
- Game-over and restart
- Best score

## Important
This is a playable prototype, not yet a final commercial 3D game. It uses simple generated 3D shapes so it can run without external art assets.

## Google Play
Before publishing, replace prototype graphics/audio with licensed assets, test on multiple Android devices, set the final application ID, app icon, privacy/data disclosures as applicable, and export an Android App Bundle (AAB) signed for release. Google Play's current requirements should be checked in Play Console before submission.
